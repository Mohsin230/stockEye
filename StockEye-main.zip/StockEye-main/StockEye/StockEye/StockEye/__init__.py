"""
Package for StockEye.
"""
